## Set-up

Download ollama: https://ollama.com/

In terminal, run: 

```bash
ollama pull llama2
```

To check if llama 2 has downloaded successfully, run: 

```bash
ollama list
```

To set up your Python environment, run the following commands: 

```bash
python -m venv .demovenv

source .demovenv/bin/activate

pip install -r requirements.txt --no-deps
```

## Usage
Running the main project implementation via the client server model:
In two separate terminals run 
```
python server.py
python client.py
```
and wait for the server to successfully start before creating the client instance (note that this could take a while if it is your first time installing the LLM).  Leave the server running and follow the instructions on the client prompts to perform various types of analysis.

### Server input:
- **LLM Model Name:** The name of the LLM model. Options for LLM models can be found here: https://ollama.com/library. Model name entered must be downloaded from ollama, and show up after running "ollama list". Example input includes: llama2, mistral, gemma, etc.

  
### Client inputs:
- **Transcript file name:** Test transcripts found in transcripts folder. Can run any of the actions on transcripts/1.csv, transcripts/2.csv, etc. 
- **User tags:** This is a comma-separate list of words/ phrases that you wish to use to tag the text (function under dev still).  For example 'global warming, weapons, peace'
  
- Actions:
  - summarize: Outputs summaries of the responses
  - sentiment: Tags each response in the transcript with a sentiment
  - keywords: Generates keywords and/ or themes that are most relevant to the responses
  - user_tag (under dev): Tags the responses with just the tags that were provided by the user
  - new_project: Scrapes the responses from the newly provided project from Kobo and uses this instead
  - update_tags: Gives the user the option to either add new tags to their list (another comma-delineated list), or clear all existing tags
  - exit: breaks and disconnects the client socket
 
### Notes on Prompts: 
https://docs.google.com/document/d/1zQ41OC0fYs2W20Jt_dWx-WCf7zAFfr6hDXmPmkWcH1g/edit

