from transformers import pipeline, BertTokenizer, BertModel
from scipy.spatial.distance import cosine
from typing import List, Tuple
from torch import Tensor

class Tagging():
    """
    Class to perform sentiment tagging on responses utilizing the BERT model
    """
    def __init__(self) -> None:
        self.model_name = "distilbert-base-uncased-finetuned-sst-2-english"
        self.sentiment_pipeline = pipeline("sentiment-analysis", model=self.model_name)

        # For keyword/theme relevance
        self.bert_model_name = 'bert-base-uncased'
        self.tokenizer = BertTokenizer.from_pretrained(self.bert_model_name)
        self.bert_model = BertModel.from_pretrained(self.bert_model_name)
        
    def assign_sentiment_tags(self, response: str) -> Tuple[str, List[str]]:
        """
        Assigns sentiment tags to the given text response.

        Args:
            response (str): The text response to analyze for sentiment.

        Returns:
            Tuple[str, List[str]]: The original response and its assigned sentiment tag.
        """
        result = self.sentiment_pipeline(response)
        tag = [result[0]['label']]
        return response, tag

    def get_embedding(self, text: str) -> Tensor:
        """
        Generates the BERT embedding for the given text.

        Args:
            text (str): The text to generate embeddings for.

        Returns:
            torch.Tensor: The mean of the last hidden state of the BERT model's output, with shape [batch_size, hidden_size].
        """
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
        outputs = self.bert_model(**inputs)
        return outputs.last_hidden_state.mean(1)

    def check_keywords(self, text: str, keywords: List[str]) -> List[Tuple[str, float]]:
        """
        Checks and evaluates the relevance of the given keywords to the text.

        Args:
            text (str): The text to compare against the keywords.
            keywords (List[str]): A list of keywords to check for relevance in the text.

        Returns:
            List[Tuple[str, float]]: A list of tuples containing relevant keywords and their similarity scores.
        """
        relevant_keywords = []
        text_embedding = self.get_embedding(text).squeeze()  # Squeezing to 1-D
        for keyword in keywords:
            keyword_embedding = self.get_embedding(keyword).squeeze()  # Squeezing to 1-D
            similarity = 1 - cosine(text_embedding.detach().numpy(), keyword_embedding.detach().numpy())
            print(keyword, similarity)
            if similarity > 0.5:  # Threshold for similarity
                relevant_keywords.append((keyword, similarity))
        return relevant_keywords

