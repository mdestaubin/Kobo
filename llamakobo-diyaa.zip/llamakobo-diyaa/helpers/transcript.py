import requests
from itertools import zip_longest
from typing import List, Dict, Tuple

def _get_asset_id_by_name(api_key: str, endpoint_url: str, project_name: str) -> str:
    """
    Fetches the asset ID for a given project name from KoboToolbox.

    Args:
        api_key (str): The API key for authentication.
        endpoint_url (str): The endpoint URL to fetch projects.
        project_name (str): The name of the project to find the asset ID for.

    Returns:
        str: The asset ID of the project.

    Raises:
        ValueError: If no project with the given name is found.
        ConnectionError: If there's an issue with the network connection or the server.
    """
    headers = {
        'Authorization': f'Token {api_key}'
    }
    try:
        response = requests.get(endpoint_url, headers=headers)
        response.raise_for_status()  # Raises HTTPError for bad responses

        projects = response.json()
        for item in projects.get('results', []):
            if item.get('name') == project_name:
                return item.get('uid')
        raise ValueError(f"No project named '{project_name}' found.")
    except requests.exceptions.HTTPError as e:
        raise ConnectionError(f"Failed to get data, HTTP error: {e}")
    except requests.exceptions.RequestException as e:
        raise ConnectionError(f"Request failed: {e}")
    except ValueError as e:
        raise ValueError(e)

def _get_asset_data_url(asset_uid: str, endpoint_url: str) -> str:
    """
    Constructs the URL to access asset data given the asset UID.

    Args:
        asset_uid (str): The unique identifier of the asset.
        endpoint_url (str): The endpoint URL to fetch projects.

    Returns:
        str: The URL to access the asset's data.
    """
    base_url, query = endpoint_url.split('?')
    base_url = base_url.rstrip('/')  # Remove trailing slash if present
    asset_url = f"{base_url}/{asset_uid}/data/?{query}"
    return asset_url

def _get_transcript_by_asset(api_key: str, asset_url: str) -> Dict:
    """
    Fetches the transcript data for a given asset URL.

    Args:
        api_key (str): The API key for authentication.
        asset_url (str): The URL to access the asset's data.

    Returns:
        Dict: The raw transcript data as a dictionary.

    Raises:
        ConnectionError: If there's an issue with the network connection or the server.
    """
    headers = {
        'Authorization': f'Token {api_key}'
    }
    try:
        response = requests.get(asset_url, headers=headers)
        response.raise_for_status()  # Raises HTTPError for bad responses
        return response.json()
    except requests.exceptions.HTTPError as e:
        raise ConnectionError(f"Failed to get transcript, HTTP error: {e}")
    except requests.exceptions.RequestException as e:
        raise ConnectionError(f"Request failed: {e}")

def _process_transcript(raw_transcript: Dict) -> Dict[int, List[Tuple[str, str]]]:
    """
    Processes the raw transcript data to organize it into a structured dictionary.

    Args:
        raw_transcript (Dict): The raw transcript data from the API.

    Returns:
        Dict[int, List[Tuple[str, str]]]: A dictionary where each key is a submission ID and each value is a list of tuples containing question and transcript text pairs.
    """
    transcript_dict = {}
    for submission in raw_transcript['results']:
        id = submission.get('_id', {})
        transcript_dict[id] = []

        # Navigate through the nested structure
        supplemental_details = submission.get('_supplementalDetails', {})
        for question, response in supplemental_details.items():
            transcript_details = response.get('transcript', {})
            transcript_text = transcript_details.get('value', 'N/A')
            transcript_dict[id].append((question, transcript_text))
    return transcript_dict

def get_kobo_transcript(api_key: str, endpoint_url: str, project_name: str) -> Dict[int, List[Tuple[str, str]]]:
    """
    Retrieves and processes the KoboToolbox transcript for a given project name.

    Args:
        api_key (str): The API key for authentication.
        endpoint_url (str): The endpoint URL to fetch projects.
        project_name (str): The name of the project to retrieve transcripts for.

    Returns:
        Dict[int, List[Tuple[str, str]]]: The processed transcript data organized by submission ID.

    Raises:
        ConnectionError: If there's an issue with the network connection or the server.
        ValueError: If no project with the given name is found.
    """
    try:
        asset_uid = _get_asset_id_by_name(api_key, endpoint_url, project_name)
        asset_url = _get_asset_data_url(asset_uid, endpoint_url)
        raw_transcript = _get_transcript_by_asset(api_key, asset_url)
        transcript_dict = _process_transcript(raw_transcript)
        return transcript_dict
    except (ConnectionError, ValueError) as e:
        print(f"Error: {e}")
        raise

def get_transcript_responses(raw_transcript: Dict[int, List[Tuple[str, str]]]) -> List[str]:
    """
    Extracts transcript responses from the structured transcript data.

    Args:
        raw_transcript (Dict[int, List[Tuple[str, str]]]): The processed transcript data organized by submission ID.

    Returns:
        List[str]: A list of transcript responses.
    """
    zipped_data = list(zip_longest(*[raw_transcript[question] for question in raw_transcript], fillvalue=(None, None)))
    responses = [t[1] for tuples in zipped_data for t in tuples if t and t[1]]
    return responses