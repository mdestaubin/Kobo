"""
TODO: This is a class I was testing to streamline the keyword generation process to ensure that output format was always consistent.  It utilizes the pretrained BERT classification model as well as NLP techniques such as term frequency-inverse document frequency (TF-IDF) to identify important keywords.  This class is currently not implemented in the code, and the LLM is used instead.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from transformers import BertTokenizer, BertModel
import numpy as np
from scipy.spatial.distance import cosine

class KeywordExtractor:
    def __init__(self):
        # Initialize BERT
        self.bert_tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        self.bert_model = BertModel.from_pretrained('bert-base-uncased')

    def extract_keywords_tfidf(self, text, top_n=10):
        # Splitting the text into sentences for analysis
        sentences = text.split('. ')
        vectorizer = TfidfVectorizer(stop_words='english')
        X = vectorizer.fit_transform(sentences)

        # Getting feature names (words)
        feature_array = np.array(vectorizer.get_feature_names_out())
        tfidf_sorting = np.argsort(X.toarray()).flatten()[::-1]

        # Extracting top n keywords
        top_keywords = feature_array[tfidf_sorting][:top_n]
        return top_keywords

    def get_bert_embedding(self, text):
        inputs = self.bert_tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
        outputs = self.bert_model(**inputs)
        return outputs.last_hidden_state.mean(1)

    def find_matches(self, extracted_keywords, provided_keywords, threshold=0.9):  # Increased threshold
        matches = set()
        for ek in extracted_keywords:
            ek_embedding = self.get_bert_embedding(ek).detach().numpy().flatten()
            for pk in provided_keywords:
                pk_embedding = self.get_bert_embedding(pk).detach().numpy().flatten()
                similarity = 1 - cosine(ek_embedding, pk_embedding)
                if similarity >= threshold:
                    matches.add((ek, pk))
        return matches


# Testing
extractor = KeywordExtractor()
text = "Well, I think a lot of people are thinking very negatively about what's going on in the world, but I have to say that overall, you know, I think the long-term trends are looking pretty positive if you just forget about current events, you know. People are healthier and there is less poverty, technology makes things easier for many people in their day-to-day lives. And of course it doesn't mean there's a lot of suffering. There is.  And there's inequality. But you have to remember that things were actually worse for the vast majority of those people around the planet, you know, 20, 30, 100 years ago, a thousand years ago. So, I think that the current state of the world could be a lot better and I think there's a lot more awareness of what the problems are; the challenges--especially around climate change, for example. But I think I'm hopeful because the trend over the last 50 to 100 years,  you know, even though we we have consumed a lot more oil and and other kinds of fuels that, you know,  I think, I think we've also made a lot of progress on another many other fronts. So I think we will probably be able to overcome these kinds of challenges related to, you know, climate change and AI, even if we don't yet know what the solution look like."

extracted_keywords = extractor.extract_keywords_tfidf(text)

provided_keywords = ["technology", "growth", "war"]
matches = extractor.find_matches(extracted_keywords, provided_keywords)

print("Extracted Keywords:", extracted_keywords)
print("Matches:", matches)
