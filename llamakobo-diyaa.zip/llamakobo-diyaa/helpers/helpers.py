from typing import Dict, List, Tuple, Optional
import csv
import re
import requests
import json
import pandas as pd

from similarity import calculate_sim, count_same


def compare_manual(df, df1, tags):
    if df.size == 0:
        index_of_current_row = 0
    else: 
        index_of_current_row = df.index[-1]+ 1
    actual_value = (df1.iloc[index_of_current_row, 1].split(','))
    #count number of common tags
    num_common_values = count_same(actual_value, tags)
    #create row, add to df
    new_row = pd.DataFrame({'new_tags': [json.dumps(tags)], 'num_common': [num_common_values]})
    return new_row


def append_similarity_df(df, text, runs_list_oneprompt):

                #run the similarity calculation and put it in a spreadsheet
                #extract the "TEXT" from the prompt, and make that one of the columns
                #make another column w the calculation
                mean_similarity, std_dev_similarity = calculate_sim(runs_list_oneprompt)
                
                new_row = pd.DataFrame({
                        'um': [runs_list_oneprompt],
                        'response': [text],
                        'similarity': [mean_similarity],
                        'std_dev_similarity': [std_dev_similarity]
                    })
                
                print(new_row)
                df = pd.concat([df, new_row], ignore_index=True)

                return df


def extract_text_from_prompt(prompt):
     # Find the position of the "TEXT:" marker
                text_start = prompt.find("TEXT:") + len("TEXT:")

                # Find the position of the "Format your response as follows" marker in prompt
                format_start = prompt.find("Format your response as follows:")

                #extract the text portion
                if format_start != -1: #ollama model prompt
                    extracted_text = prompt[text_start:format_start].strip()
                else:
                    extracted_text = prompt[text_start:].strip() #open ai model prompt

                return extracted_text


def measure_consistency(model, prompt):
    """
      for i in range(10):

                    tag = self.model.generate(prompt)

                    #  print("THIS IS THE OUTPUT OF LLM")
                    # print(f"{tag}\n")
                    #if 'none' in tag or 'None' in tag: #TODO
                       # tag = 'None'
                    #else:

                    ----- this is ollama 
                    pattern = r"\d+\.\s*((?:.(?!\d+\.\s))+.)"
                    matches = re.findall(pattern, tag, re.DOTALL)
                    tag = [match.strip() for match in matches]
                    
                    # Filter out elements containing the strings 'not represented', 'not mention', or 'not mentioned'
                    tag = [tag.strip() for tag in tag if not re.search(r'not represented|not mention|not mentioned', tag, re.IGNORECASE)]
                
                    print("TAG AFTER MATCHSTRIP, this is passed to client"),
                    print(tag)
                    ----- this is ollama

                    #TODO the problem here is that you cant extract matching tags 
                    #i guess you can try without doing that matching of the provided tags... just see if it is consistent. 
                    print("HERE IS TAG")
                    print(tag)
                    #runs_list_oneprompt += tag
                    runs_list_oneprompt.append(tag) #TODO appending for gpt but += for the other one. try to get these consistent 
                
    """
    runs_list_oneprompt = []

    for i in range(3):
        tag = model.generate(prompt)
        tag = extract_only_tags(tag) #extract not needed for openai
        #runs_list_oneprompt += tag
        runs_list_oneprompt.append(tag) #TODO appending for gpt but += for the other one. try to get these consistent 
    
    return runs_list_oneprompt


def extract_only_tags(tag):
    """
    LLM model prompts return tags identified in numbered list. This response is often too verbose. Method standardises it using regex to
    extract only the tags identified and returns them as elements in a list.  

    Args:
        tag: String response from LLM including tags, and other details, in a numbered list format.
    
    Returns: 
        A list whose elements are each of the tags identified by the LLM
    """

    pattern = r"\d+\.\s*((?:.(?!\d+\.\s))+.)"
    matches = re.findall(pattern, tag, re.DOTALL)
    tag = [match.strip() for match in matches]
                    
    # Filter out elements containing the strings 'not represented', 'not mention', or 'not mentioned'
    tag = [tag.strip() for tag in tag if not re.search(r'not represented|not mention|not mentioned|no mention', tag, re.IGNORECASE)]
                
    #print("TAG AFTER MATCHSTRIP, this is passed to client"),
    #print(tag) 

    return tag
        
#TODO optional input should be temperature
def fetch_response_from_model(prompt, model_name):
    """
    
    Args:
        prompt: prompt for LLM created based on user input 
        model_name: string name of LLM model
    
    Returns: 
        string containing LLM response message
    """
    url = "http://localhost:11434/api/generate"
    headers = {'Content-Type': 'application/json'}
    data = {
        "model": model_name,
        "prompt": prompt,
        "temperature": 0.1
    }
    response = requests.post(url, headers=headers, json=data) 
    if response.status_code == 200:
        try:
            full_response = ''
            lines = response.text.strip().split('\n')
            for line in lines:
                if line.strip():  # Ensure line is not empty
                    response_data = json.loads(line)
                    full_response += response_data["response"]
            return full_response
        except json.JSONDecodeError as e:
            print("JSON Decode Error:", e)
            return None
    else:
        print("Error", response.status_code, response.text)
        return None

#TODO
def extract_matching_tags(provided_list, user_tags):
        """
        
        """
        extracted_tags = []
        for item in provided_list:
            for tag in user_tags:
                if tag.lower() in item.lower():
                    # Handle tags with '/'
                    full_tag = tag
                    if '/' in tag:
                        full_tag = next((t for t in user_tags if t.lower() == tag.lower()), tag)
                    if full_tag not in extracted_tags:
                        extracted_tags.append(full_tag)
                    break  # Stop checking other tags once a match is found
        return extracted_tags

def extract_and_save_columns(input_csv_file, column_names):
    """
    Extracts specified columns from an input CSV file. 

    Args:
        input_csv_file (str): Path to the input CSV file.
        output_csv_file (str): Path to the output CSV file.
        column_names (list): List of column names to extract.
    """
    # Read the CSV file
    df = pd.read_csv(input_csv_file)
    # Check if the specified columns exist in the DataFrame
    for column_name in column_names:
        if column_name not in df.columns:
            print(f"Column '{column_name}' does not exist in the CSV file.")
            return
    # Extract the specified columns
    columns_data = df[column_names]
    return columns_data

def create_df(manual_tag_file, accuracyData):
    """
    
    Args:
        manual_tag_file (str)
        accuracyData (bool)
    """
    if accuracyData:
        columns_to_extract = input("Enter name of column with response, and name of column with identified tags: ")
    else: 
        columns_to_extract = input("Enter name of column with response: ")
    columns_to_extract = [item.strip() for item in columns_to_extract.split(',')]
    df1 = extract_and_save_columns(manual_tag_file, columns_to_extract)
    df = pd.DataFrame(columns=['new_tags'])
    return df1, df


def create_summary_prompts(transcript_dict: Dict[str, List[Tuple[str, str]]]) -> List[str]:
    """
    Generates summary prompts from a given transcript dictionary.

    Args:
        transcript_dict (Dict[str, List[Tuple[str, str]]]): A dictionary where each key corresponds to a session or identifier
            and its value is a list of question-response pairs.

    Returns:
        List[str]: A list of summary prompts for each response in the transcript.
    """
    prompts = []
    for _, q_pair in transcript_dict.items():
        for i in range(len(q_pair)):
            user_response = q_pair[i][1].replace('\n', '')
            question = q_pair[i][0].replace('\n', '')
            prompt = f"Summarize the response: '{user_response}' given to the question: '{question}' \n"
            #DIYAA TODO
            #prompt = f" Write a summary of the following text reeturn your response which covers the key points of the text."
            prompts.append(prompt)
    return prompts

def create_user_tags(user_tags: Optional[str]) -> Optional[List[str]]:
    """
    Prompts the user to enter a list of descriptive words to use as tags, separated by commas.
    Returns a cleaned list of non-empty tags or None if no tags are provided.
    
    Args:
        user_tags (Optional[str]): A string from an input containing a comma-separated list of tags.
    Returns:
        Optional[List[str]]: A list of user-provided tags or None if no tags were entered.
    """
    if not user_tags:
        return None
    user_tags = [tag.strip() for tag in user_tags.split(',') if tag.strip()]
    return user_tags

def create_tag_prompts(transcript_dict: Dict[str, List[Tuple[str, str]]], user_tags: List[str]) -> List[str]:
    """
    Generates prompts for tagging responses with user-defined tags based on the transcript content.

    Args:
        transcript_dict (Dict[str, List[Tuple[str, str]]]): A dictionary with question-response pairs.
        user_tags (List[str]): A list of tags provided by the user.

    Returns:
        List[str]: A list of prompts instructing to identify keywords that match user-defined tags.
    """
    prompts = []
    for _, q_pair in transcript_dict.items():
        for i in range(len(q_pair)):
            user_response = q_pair[i][1].replace('\n', '')
            #most accuracy,  consistency, and completeness out of other options
            #this is the best for most ollama options
            """prompt = fGiven the list of fields: ({user_tags}),
            determine which fields are represented in the following text. In a numbered list format, return the fields represented in the text. If the provided fields are not represented in the text, do not return them.

            TEXT: {user_response}

            Format your response as follows:
            1. [Field Name]
            2. [Field Name]
            """

            #this is a seperate prompt that works for gpt (openai)
            prompt = f"""Check if each of the following themes is mentioned substantively in the given interview text. For each text, return a list indicating whether the theme was mentioned (TRUE) or not (FALSE). Provide the results as a JSON object without any additional explanation.
            THEMES: {user_tags}
            TEXT: {user_response}
            """
            prompts.append(prompt)
    return prompts

def create_keyword_prompts(transcript_dict: Dict[str, List[Tuple[str, str]]]) -> List[str]:
    """
    Generates prompts for identifying the most relevant keywords or major themes from the transcript.

    Args:
        transcript_dict (Dict[str, List[Tuple[str, str]]]): A dictionary where each key is a session or identifier,
            and the value is a list of question-response pairs.

    Returns:
        List[str]: A list of prompts asking for relevant keywords or themes from each response.
    """
    prompts = []
    for _, q_pair in transcript_dict.items():
        for i in range(len(q_pair)):
            user_response = q_pair[i][1].replace('\n', '')
            #prompt = f"List the five most relevant keywords/ major themes in this text {user_response} in a comma-delineated list format such as ['item1', 'item2', 'item3']"
            prompt = f"In a comma-delineated list format such as ['item1', 'item2', 'item3'], list the five most relevant keywords/ major themes in the following text: {user_response}."
            prompts.append(prompt)
    return prompts



# DEPRECATED: Used originally for CSV files (replaced with get_kobo_transcript)
#TODO THIS ISNT WORKING
def _parse_transcript(transcript: str, responseColumn: str) -> Dict[str, List[Tuple[str, str]]]:
    transcript_dict = {}
    with open(transcript, 'r') as csvfile:
        #reader = csv.DictReader(csvfile, delimiter=';', quotechar='"')
        reader = csv.DictReader(csvfile, delimiter=',')
        data_dict = {row['_index']: row for row in reader} #TODO DIYAA THE _INDEX HERE IS THE PROBLEM LOLa

    for user, _ in data_dict.items():
        transcript_dict[user] = []
        #pattern = r"\s*-\s*transcript\s*"
        #pattern = fr"\s*-\s*{re.escape(responseColumn)}\s*"
        escaped_user_input = re.escape(responseColumn)
        pattern = fr"\s*{escaped_user_input}\s*"
        for question, response in data_dict[user].items():
            if re.search(pattern, question):
                transcript_dict[user].append((question, response))
    return transcript_dict


#SO IF YOU ARE READING INTO A CSV FROM KOBO DATA
#NEED TO DECIDE ON WHAT THE COLUMN CONTAINING 'TRANSLATION/RESPONSE' NEEDS TO BE SO U HAVE TO CHANGE THE PATTERN
#NEED TO ENSURE THAT _INDEX IS AT THE FINAL COLUMN IN THE CSV

# DEPRECATED: Used originally for CSV files (replaced with get_kobo_transcript)
"""def _parse_iraq_transcript(transcript: str, lol:str) -> Dict[str, List[Tuple[str, str]]]:
    transcript_dict = {}
    with open(transcript, 'r') as csvfile:
        reader = csv.DictReader(csvfile, delimiter=',')
        data_dict = {row['_index']: row for row in reader}

    for user, _ in data_dict.items():
        transcript_dict[user] = []
        pattern = r"\s*Translation\s*"
        for question, response in data_dict[user].items():
            if re.search(pattern, question):
                transcript_dict[user].append((question, response))
    return transcript_dict"""