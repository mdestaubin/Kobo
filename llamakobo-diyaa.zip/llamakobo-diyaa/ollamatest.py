import requests 
import json


"""
url = "http://localhost:11434/api/generate"
headers = {'Content-Type': 'application/json'}
data = {
        "model": "llama2",
        "prompt": "Why is the sky blue?"
}

response = requests.post(url, headers=headers, data=json.dumps(data))

if response.status_code == 200:
    try:
        # Initialize an empty string to collect the full response
        full_response = ''
        
        # Split the response text into lines
        lines = response.text.strip().split('\n')
        
        # Iterate over each line
        for line in lines:
            if line.strip():  # Make sure the line is not empty
                # Load each line as a JSON object
                response_data = json.loads(line)
                # Concatenate the 'response' part of each JSON object
                full_response += response_data["response"]
                  
        # Print the concatenated response
        print(full_response)
    except json.JSONDecodeError as e:
        print("JSON Decode Error:", e)
else:
    print("ERror", response.status_code, response.text)

def fetch_response_from_model(prompt, model_name):
    url = "http://localhost:11434/api/generate"
    headers = {'Content-Type': 'application/json'}
    data = {
        "model": model_name,
        "prompt": prompt,
        "temperature": 0.1
    }

    response = requests.post(url, headers=headers, json=data) 

    if response.status_code == 200:
        try:
            full_response = ''
            lines = response.text.strip().split('\n')
            for line in lines:
                if line.strip():  # Ensure line is not empty
                    response_data = json.loads(line)
                    full_response += response_data["response"]
            return full_response
        except json.JSONDecodeError as e:
            print("JSON Decode Error:", e)
            return None
    else:
        print("Error", response.status_code, response.text)
        return None
"""
def main():
    # Example usage:
    user_prompt = "Why is the sky blue?"
    result = fetch_response_from_model(user_prompt)
    if result:
        print(result)

if __name__ == "__main__":
    main()