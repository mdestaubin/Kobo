"""
This script facilitates the execution of a model either locally or remotely based on user input. 
It uses Click for CLI interaction, allowing users to specify whether they want to run the model locally 
or remotely, and to provide a list of questions (prompts) as input. The script handles the execution 
flow accordingly, logging the chosen execution path and managing the subprocess call for remote execution.
"""

import click
import logging
import subprocess
from model_classes.local_model import run_local
from model_classes.modal_model import run_remote
import shlex

logging.basicConfig(level=logging.INFO)

@click.command()
@click.option('--local', is_flag=True, help='If used then local implementation will be run, otherwise defaults to remote.')
@click.option('--prompts', help='Provide a list of question(s) in a comma separated list with quotes')

def main(local, prompts):
    if local:
        logging.info("Running locally")
        run_local(prompts)
        #run_remote(prompts)
    else:
        prompts = shlex.quote(prompts)
        command = shlex.split(f"modal run modal_model.py::run_remote")
        logging.info(f"Running remotely using command: {command}")

        process = subprocess.Popen(command)
        process.wait()

if __name__ == "__main__":
    main()