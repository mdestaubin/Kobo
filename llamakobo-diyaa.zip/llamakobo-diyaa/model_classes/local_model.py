import os
import openai
import json
import logging
import sys
#import llm
import subprocess
import shlex
import time
#from openai import OpenAI
import json
from dotenv import load_dotenv

#diyaa TODO
#from test import run_modal_command


sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from helpers.helpers import fetch_response_from_model
from openai_test import openai_call, load_api_key

logging.basicConfig(level=logging.INFO)

#MODEL_NAME = "mlc-chat-Llama-2-7b-chat-hf-q4f16_1"
#MODEL_DOWNLOAD = "Llama-2-7b-chat"ge
#MODEL_DIRECTORY = "model_download/mlc/dist/prebuilt/"

"""
def model_setup(model_download_name: str) -> bool:
    os.environ['LLM_USER_PATH'] = 'model_download'
    time.sleep(2)

    # llm mlc setup
    setup_command = "llm mlc setup"
    logging.info(f"Beginning llm mlc setup, running command: {setup_command}")
    setup_process = subprocess.Popen(shlex.split(setup_command), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        stdout, stderr = setup_process.communicate(timeout=200)
        output_str = stdout.decode('utf-8')
        success = "Ready to install models in model_download/mlc"
        if success in output_str:
            logging.info(success)
        else:
            logging.info("MLC setup failed with reason: ", output_str)
    except subprocess.TimeoutExpired as e:
        setup_process.kill()
        logging.info(f"MLC setup failed with reason: {e}")
        return False

    # llm mlc download-model {model_download_name}
    download_command = f"llm mlc download-model {model_download_name}"
    logging.info(f"Beginning model download, running command: {download_command}")
    download_process = subprocess.Popen(shlex.split(download_command))
    timeout = 1000  # in seconds
    start_time = time.time()
    while True:
        return_code = download_process.poll()
        if return_code is None:
            elapsed_time = time.time() - start_time
            if elapsed_time > timeout:
                logging.info("Process took too long. Terminating.")
                download_process.terminate()
                time.sleep(5) # to give process time to fully terminate and reallocate resources
                break
            time.sleep(1)
        else:
            logging.info(f"Model {model_download_name} was downloaded successfully!")
            return True

    return False
"""

class Model:
    def __init__(self, model_name: str) -> None:
        #os.environ['LLM_USER_PATH'] = 'model_download'
        #time.sleep(2)

        # Check to see if model already exists
        #if os.path.exists(MODEL_DIRECTORY) and any(os.scandir(MODEL_DIRECTORY)):
         #   logging.info(f"Model {MODEL_NAME} already exists on machine!")
        #else:
         #   setup_status = model_setup(MODEL_DOWNLOAD)
          #  if not setup_status:
           #     raise Exception
        
       # time.sleep(2)
        
        # self.model = llm.get_model(MODEL_NAME)
        # self.template = """<s>[INST] <<SYS>> \n{system}\n<</SYS>>\n\n{user} [/INST]"""

        self.model_name = model_name #DIYAA TODO: check to see if model exists locally. if not, throw error. 

        """def generate(self, q): #divya's
        response = run_modal_command(q)
        return response"""

    def generate(self, q): #DIYAA TODO (fetch_response can be moved to this class, so no self.model_name needed as parameter)
        #TODO below this is for ollama models
        #response = fetch_response_from_model(q, self.model_name)
        
        #below for openai api only

        load_api_key()       
        response = openai_call(q)
        return response

def run_local(prompts):
    prompts = [prompt.strip('"').strip() for prompt in prompts.split(';;')]
    m = Model()
    for prompt in prompts:
        print(m.generate(prompt))