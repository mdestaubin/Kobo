import modal
import os

stub = modal.Stub()

def download_model_to_folder():
    print("Fetching llama 2 model!")
    from huggingface_hub import snapshot_download
    os.mkdir("model")
    snapshot_download(
        "meta-llama/Llama-2-13b-chat-hf",
        local_dir="model",
        token=os.environ["HUGGINGFACE_TOKEN"],
    )

MODEL_DIR = "model"

image = (
    modal.Image.from_registry("nvcr.io/nvidia/pytorch:22.12-py3")
    .pip_install(
        "torch==2.0.1", index_url="https://download.pytorch.org/whl/cu118"
    )
    .pip_install(
        "vllm @ git+https://github.com/vllm-project/vllm.git@805de738f618f8b47ab0d450423d23db1e636fa2",
        "typing-extensions==4.5.0",
    )
    .pip_install("hf-transfer~=0.1")
    .env({"HF_HUB_ENABLE_HF_TRANSFER": "1"})
    .run_function(download_model_to_folder, secret=modal.Secret.from_name("my-huggingface-secret"))
)

stub = modal.Stub("llama2_setup", image=image)

@stub.cls(gpu="A100", secret=modal.Secret.from_name("my-huggingface-secret"))
class Model:
    def __enter__(self):
        from vllm import LLM

        # Load model
        self.llm = LLM(MODEL_DIR)
        self.template = """<s>[INST] <<SYS>>
{system}
<</SYS>>

{user} [/INST] """

    @modal.method()
    def generate(self, user_questions):
        from vllm import SamplingParams

        prompts = [
            self.template.format(system="", user=q) for q in user_questions
        ]
        sampling_params = SamplingParams(
            temperature=0.75,
            top_p=1,
            max_tokens=800,
            presence_penalty=1.15,
        )
        result = self.llm.generate(prompts, sampling_params)
        num_tokens = 0
        for output in result:
            num_tokens += len(output.outputs[0].token_ids)
            print(output.prompt, output.outputs[0].text, "\n\n", sep="")
        print(f"Generated {num_tokens} tokens")


@stub.local_entrypoint()
def run_remote(prompts):
    prompts = [prompt.strip('"').strip() for prompt in prompts.split(';;')]
    model = Model()
    for prompt in prompts:
        model.generate.remote([prompt])

if __name__ == "__main__":
    run_remote()