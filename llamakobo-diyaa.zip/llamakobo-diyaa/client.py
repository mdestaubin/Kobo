import grpc
import ast
import os
import re
import csv
import json
import pandas as pd
from typing import List, Optional
import protos.service_pb2_grpc as pb2_grpc
import protos.service_pb2 as pb2
from helpers.helpers import create_summary_prompts, create_user_tags, create_tag_prompts, create_keyword_prompts, _parse_transcript, extract_matching_tags, create_df, compare_manual
from helpers.transcript import get_kobo_transcript, get_transcript_responses
from itertools import zip_longest
from writecsv import extract_and_save_columns
from similarity import count_same
ADDRESS = "localhost" 
PORT = 11912

class Client:
    """
    A client class for interacting with a transcript analysis service using gRPC.

    Attributes:
        project (str): The name of the Kobo project to analyze.
        user_tags (Optional[List[str]]): A list of user-defined tags for categorization.
    """

    #DIYAA TODO
    def __init__(self, transcript, user_tags: Optional[List[str]]):
        # Init client/ server channels
        self.channel = grpc.insecure_channel('localhost:11912')
        self.stub = pb2_grpc.TranscriptAnalysisStub(self.channel)

        # Init provided transcripts and user tags
        self.transcript = transcript
        self.user_tags = user_tags

        # Init parsed transcripts and responses
        self.full_text = None
        self.transcript_responses = None
   

    #DIYAA TODO
    def __enter__(self):
        # Parse the full transcript
        #self.full_text = _parse_iraq_transcript(self.transcript)

        # TODO
        response_name = input("Enter name of column in transcript csv containing responses to analyse: ")
        print(response_name)
        self.full_text = _parse_transcript(self.transcript, response_name)

        # Create question/ response tuples
        zipped_data = list(zip_longest(*[self.full_text[question] for question in self.full_text], fillvalue=(None, None)))
        responses = []
        for tuples in zipped_data:
            responses.extend([t[1] for t in tuples if t and t[1]])
        
        # Store question response tuples
        self.transcript_responses = responses
        return self


    """def __init__(self, project, user_tags: Optional[List[str]]):

        Initializes the client with the project name and optional user-defined tags.

        Args:
            project (str): The name of the project.
            user_tags (Optional[List[str]]): User-defined tags, if any.

        self.channel = grpc.insecure_channel(f"{ADDRESS}:{PORT}")
        self.stub = pb2_grpc.TranscriptAnalysisStub(self.channel)

        self.project = project
        self.user_tags = user_tags

        self.full_text = None
        self.transcript_responses = None

        self.api_key = os.getenv('API_KEY')
        self.endpoint_url = 'https://kf.kobotoolbox.org/api/v2/assets/?format=json'

    def __enter__(self):
       
        Context manager entry point. Fetches the full transcript text via the Kobo API and prepares it for analysis.

        Returns:
            self: The instance of the Client.

        self.full_text = get_kobo_transcript(self.api_key, self.endpoint_url, self.project)

        # Create question/ response tuples used for processing
        self.transcript_responses = get_transcript_responses(self.full_text)
        return self"""

    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Context manager exit point. Closes the gRPC channel upon failure/ exit from the client.
        """
        self.channel.close()

    def summarize_request(self):
        """
        Utilizes server function summarizeAnswer to provide a summary of the transcript
        """
        try:
            summary_prompt = create_summary_prompts(self.full_text)
            for prompt in summary_prompt:
                request = pb2.summarizeAnswerRequest(prompt=prompt)
                response = self.stub.summarizeAnswer(request)
                print(f"Summarized Response: {response.response}\n")
        except Exception as e:
            print(e)
    
    def tag_sentiment(self):
        """
        Utilizes server function tagSentiment to perform sentiment analysis on each response
        """
        try:
            request = pb2.tagRequest(transcript_responses=self.transcript_responses)
            response = self.stub.tagSentiment(request)
            for tagged in response.tagged_responses:
                print(f"Text: {tagged.response}\nTag: {tagged.tags}\n")
        except Exception as e:
            print(e)
    
    def identify_keywords(self):
        """
        Utilizes server function identifyKeywords to return a list of keywords/ themes in the response
        """
        try:
            tag_prompts = create_keyword_prompts(self.full_text)
            request = pb2.tagRequest(prompt=tag_prompts)
            response = self.stub.identifyKeywords(request)
            for tagged in response.tagged_responses:
                full_response = (', '.join(tagged.tags))

                print(f"Tags: {full_response}")

                #print(f"Tags: {''.join(tagged.tags)}\n")
        except Exception as e:
            print(e)

    """
    def tag_user_created(self):
        
        Utilizes server function tagUserCreated to 
        Note:
            TODO: Adding user created tags to responses using the Llama 2-7b model is currently unreliable-- tags are often unrelated to the text and/or ignore the user's desired tags.

        # Check if user created any tags
        if self.user_tags is None:
            print("No user created tags provided")
            return None
        try:
            #tag_prompts = create_tag_prompts(self.full_text, self.user_tags)
            #TODO

            # create keywords prompt
            tag_prompts = create_keyword_prompts(self.full_text)
            request = pb2.tagRequest(prompt=tag_prompts)

            # TODO: Display the tags found
            response = self.stub.tagUserCreated(request)
        except Exception as e:
            print(e)
    """


    """
    if user_tag option, the tags identified will be written into a csv file in a row containing the response and the new tags identified
    """
    def tag_user_created(self, accuracyData = False, consistencyData = False):
        #so compare to manual tags requires both the transcript, and the column name with the tags. instead of doing that, just make it an optional parameter/optonal input. 
        #even though you pass in the transcript, maybe inside the compare_to_manual_tags option, u ask if you want to compare to any existing tags or not. 
        
        df1, df = create_df(self.transcript, accuracyData)
        
        if self.user_tags is None:
            print("No user created tags provided")
            return None
        try:
            tag_prompts = create_tag_prompts(self.full_text, self.user_tags)
            request = pb2.tagRequest(prompt=tag_prompts, tag_list=self.user_tags)
            response = self.stub.tagUserCreated(request)

            for tagged in response.tagged_responses: #DIYAA TODO: add --details flag to get explanation of keyword tags. 
                if tagged.tags:
                    new_tags = extract_matching_tags(tagged.tags, self.user_tags)
                else: 
                    new_tags = "None"
                new_row = pd.DataFrame({'new_tags': [json.dumps(new_tags)]}) 

                if accuracyData:
                    new_row = compare_manual(df, df1, new_tags)
                
                #new_tags = ", ".join(new_tags) #formatted string
                df = pd.concat([df, new_row], ignore_index=True)
            
            df = pd.concat([df1, df], axis=1)
            df.to_csv("./tags_identified.csv", index=False)    
            print("Done")
        except Exception as e:
            print(e)

    def update_project(self, new_project: str) -> None:
        """
        Updates the project name and fetches the new project's transcript.

        Args:
            new_project (str): The new project name to fetch transcripts for.
        """
        self.project = new_project
        self.full_text = get_kobo_transcript(self.api_key, self.endpoint_url, self.project)
        self.transcript_responses = get_transcript_responses(self.full_text)

    def add_user_tags(self, new_user_tags: Optional[List[str]]) -> None:
        """
        Updates the user-defined tags by appending new tags to the existing list,
        avoiding duplicates.

        Args:
            new_user_tags (Optional[List[str]]): The new list of user-defined tags to be added.
        """
        new_tags = create_user_tags(new_user_tags)

        if self.user_tags is None:
            self.user_tags = new_tags
        elif new_tags is not None:
            self.user_tags = list(set(self.user_tags + new_tags))
            
    def clear_user_tags(self) -> None:
        """
        Clears all user-defined tags.
        """
        self.user_tags = None
        print(self.user_tags)


if __name__ == '__main__':
        # Get transcript name and user tags
        transcript = input("Transcript file name?: ")
        user_tags_input = input("Enter a list of descriptive words to use as tags for your transcript (or leave blank): ")
        user_tags = create_user_tags(user_tags_input)

        with Client(transcript, user_tags) as c:
            while True:
                #req = input("summarize/ sentiment/ exit/ user_tag/ keywords: ")\
                req = input("summarize/ sentiment/ exit/ user_tag/ keywords/ user_tag_consistency/ user_tag_accuracy ")
                if req == "summarize":
                    c.summarize_request()
                elif req == "sentiment":
                    c.tag_sentiment()
                elif req == "user_tag":
                    c.tag_user_created()
                elif req == "keywords":
                    c.identify_keywords()
                elif req == "user_tag_consistency": #TODO
                    c.tag_user_created()
                elif req == "user_tag_accuracy": #TODO
                    c.tag_user_created(accuracyData = True)
                elif req == "exit":
                    break

"""if __name__ == '__main__':
    # Get transcript name and user tags
    project = input("Kobo project name (ie 'Transcript analysis testing project'): ")
    user_tags_input = input("Enter a list of descriptive words to use as tags for your transcript (or leave blank): ")
    user_tags = create_user_tags(user_tags_input)

    with Client(project, user_tags) as c:
        while True:
            req = input("summarize/ sentiment/ keywords/ user_tag/ new_project/ update_tags: ")
            if req == "summarize":
                c.summarize_request()
            elif req == "sentiment":
                c.tag_sentiment()
            elif req == "keywords":
                c.identify_keywords()
            elif req == "user_tag":
                c.tag_user_created()

            elif req == "new_project":
                new_project = input("Enter new Kobo project name: ")
                c.update_project(new_project)
            
            elif req == "update_tags":
                action = input("Add tags or clear all? add/clear: ")
                if action == "add":
                    new_user_tags = input("Enter new user tags (comma-separated): ")
                    c.add_user_tags(new_user_tags)
                elif action == "clear":
                    c.clear_user_tags()

            elif req == "exit":
                break"""