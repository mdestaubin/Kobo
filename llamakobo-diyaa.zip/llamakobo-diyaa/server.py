import ast
import re
import grpc
import pandas as pd
from concurrent import futures
import protos.service_pb2_grpc as pb2_grpc
import protos.service_pb2 as pb2
import time
from model_classes.local_model import Model
from similarity import calculate_sim
#from model_classes.modal_model import Model

from helpers.helpers import extract_only_tags, measure_consistency, append_similarity_df, extract_text_from_prompt

from helpers.tagging import Tagging
import logging

logging.basicConfig(level=logging.INFO)

ADDRESS = "localhost" 
PORT = 11912

class Server(pb2_grpc.TranscriptAnalysisServicer):
    """
    Server class to provide various text analysis functionality

    This class provides methods to summarize text, tag sentiment, identify keywords, and apply user-created tags to given text inputs.

    Attributes:
        model (Model): An instance of the Model class (LLM) used for generating text analysis.

    Methods:
        summarizeAnswer(request, context): Returns a summarized version of the responses
        tagSentiment(request, context): Tags the responses with sentiment labels
        identifyKeywords(request, context): Identifies keywords/ themes in the responses
        tagUserCreated(request, context): Applies user-defined tags to the responses
    """
    def __init__(self):
        model_name = input("Enter name of LLM model to use: ")
        self.model = Model(model_name)

    def summarizeAnswer(self, request: pb2.summarizeAnswerRequest, context) -> pb2.summarizeAnswerResponse:
        """
        Summarizes the text provided in the request (response).

        Args:
            request: The request object containing the text to be summarized.
            context: The gRPC context.
        Returns:
            A gRPC response containing the summarized text.
        Raises:
            Exception: If summarization fails.
        """
        try:
            logging.info(f"Summarizing response text '{request.prompt[25:45]}...'")
            response_text = self.model.generate(request.prompt)
            #response_text = run_remote(request.prompt)
            #response_text = self.model.generate.remote(request.prompt) #DIYAA TODO
            return pb2.summarizeAnswerResponse(response=response_text)
        except Exception as e:
            logging.warn(f"Summarizing this response failed with message: {e}")
            raise

    def tagSentiment(self, request: pb2.tagRequest, context) -> pb2.tagResponse:
        """
        Tags the sentiment of transcript responses provided in the request.

        Args:
            request: The request object containing the transcript responses.
            context: The gRPC context.
        Returns:
            A gRPC response containing the transcript responses tagged with sentiment.
        Raises:
            Exception: If sentiment tagging fails.
        """
        try:
            t = Tagging()
            tagged_list = []
            for response in request.transcript_responses:
                response, tag = t.assign_sentiment_tags(response)
                tagged_list.append(pb2.taggedTuple(response=response, tags=tag))
            return pb2.tagResponse(tagged_responses=tagged_list)
        except Exception as e:
            logging.warn(f"Sentiment tagging this response failed with message: {e}")
            raise
    
    def identifyKeywords(self, request: pb2.tagRequest, context) -> pb2.tagResponse:
        """
        Identifies keywords and themes in the input prompts.

        Args:
            request: The request object containing the prompts for keyword identification.
            context: The gRPC context.
        Returns:
            A gRPC response containing the prompts tagged with identified keywords and themes.
        Raises:
            Exception: If keyword identification fails.
        """
        tagged_responses = []
        try:
            logging.info(f"Tagging keywords and themes for '{request.prompt[25:45]}")
            for prompt in request.prompt: 
              #  print(prompt)
                tag = self.model.generate(prompt)
                #standardises with regex so keywords are put in a list with no extra details/justification
                tag = re.findall(r'^\d+\.\s+([^:\-\n]+?)\s*(?:-|:)', tag, re.MULTILINE) #DIYAA TODO: add --details flag to get explanation of keyword tags. 
                tagged_responses.append(pb2.taggedTuple(response=prompt, tags=tag))
            return pb2.tagResponse(tagged_responses=tagged_responses)
        except Exception as e:
            logging.warn(f"Tagging failed with message: {e}")
            raise

    def tagUserCreated(self, request: pb2.tagRequest, context) -> pb2.tagResponse:
        """
        Applies user-defined tags to the input prompts.

        Args:
            request: The request object containing the prompts for user-defined tagging.
            context: The gRPC context.
        Returns:
            A gRPC response containing the prompts tagged with user-defined tags.
        Raises:
            Exception: If tagging fails.

        Note:
            TODO: Adding user created tags to responses using the Llama 2-7b model is currently unreliable-- tags are often unrelated to the text and/or ignore the user's desired tags.
        """
        tagged_responses = []
        df = pd.DataFrame(columns=['response', 'mean_similarity', 'std_dev_similarity']) #this is for consistency measurement

        try:
            logging.info(f"Tagging with user provided tags")
            for prompt in request.prompt:
                # TODO: generate method needs to be editedd depending on whether openai or another llm is being used
                tag = self.model.generate(prompt)

                #tag = extract_only_tags(tag) #extract not needed for openai
                tagged_responses.append(pb2.taggedTuple(response=prompt, tags=tag))

                #TODO: next 3 lines only used when consistency is being measured (user_tag_consistency)
                """runs_list_oneprompt = measure_consistency(self.model, prompt)
                df = append_similarity_df(df, extract_text_from_prompt(prompt), runs_list_oneprompt)
            df.to_csv("./test_consistency.csv", index=False)"""

            return pb2.tagResponse(tagged_responses=tagged_responses)
        except Exception as e:
            logging.warn(f"tagging failed with message: {e}")
            raise



if __name__ == '__main__':
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))  # create a gRPC server
    pb2_grpc.add_TranscriptAnalysisServicer_to_server(Server(), server)  # register the server to gRPC

    server.add_insecure_port("{}:{}".format(ADDRESS, PORT))
    server.start()
    logging.info(f'Server is listening on {ADDRESS}:{PORT}!')
    
    try:
        while True:
            time.sleep(64 * 64 * 100)
    except KeyboardInterrupt:
        server.stop(0)
        logging.info("Server has been stopped.")