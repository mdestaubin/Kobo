import csv
import os
import pandas as pd
import json

# from openai_test import load_api_key
import openai

# from openai import OpenAI
from dotenv import load_dotenv

"""Passing in codebook hasn't been integrated to the full server.py and client.py yet
running this file (codebook_tags.py) gets u the gpt response"""

# NEXT TODO
# try out the other barriers/enablers/etc and see what they look like as gpt responses
# try to clean up the accuracy and consistency stuff on the og code
# figure out how to include this in the original code? do you even neeed to include it??


def load_api_key():
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key is None:
        raise ValueError(
            "API key not found. Make sure the .env file is in the correct location and contains the OPENAI_API_KEY variable."
        )
    openai.api_key = api_key


def call_gpt(prompt):
    """method just makes a call to api and returns the response from gpt"""
    completion = openai.chat.completions.create(
        model="gpt-4o-mini", messages=[{"role": "user", "content": prompt}]
    )
    response = completion.choices[0].message
    return response.content


def xlsx_to_df(file_path, sheet_name=None):
    # Load the Excel file
    excel_file = pd.ExcelFile(file_path)

    # List available sheet names
    sheet_names = excel_file.sheet_names

    # If there's only one sheet, automatically select it
    if len(sheet_names) == 1:
        sheet_name = sheet_names[0]
        print(
            f"Only one sheet found in xlsx: '{sheet_name}', reading it automatically."
        )
    else:
        # If more than one sheet, prompt for a valid sheet name if not provided
        if not sheet_name or sheet_name not in sheet_names:
            print("Available sheets:", sheet_names)
            sheet_name = input("Please provide a valid sheet name: ")

    # Read the specified sheet
    if sheet_name in sheet_names:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        return df  # Return the DataFrame instead of printing it
    else:
        raise ValueError(f"Sheet '{sheet_name}' not found in the Excel file.")


def csv_to_json(df):
    """given file path to a csv containing two columns (Code, Definition)
    method reads into the csv (which is the codebook) and creates a list of json objects (code: definition)
    """
    survey_question = None
    in_target_section = False
    analysis_question_found = False
    potential_analysis_questions = []

    analysis_question = input("Enter analysis question: ")

    # Check if the first row contains the headers or a survey question
    if "Code" in df.iloc[0].values and "Definition" in df.iloc[0].values:
        # If the first row contains the headers, treat it as such
        df.columns = df.iloc[0]  # Set the headers from the first row
        df = df[1:].reset_index(drop=True)  # Skip the first row (header row only)
    else:
        # If the first row contains a survey question, extract it
        survey_question = df.iloc[
            0, 0
        ]  # Extract the survey question from the first column
        # print(f"Extracted Survey Question: {survey_question}")

    # Identify the header by finding where 'Code' and 'Definition' are located
    header_row_index = None
    for i, row in df.iterrows():
        if "Code" in row.values and "Definition" in row.values:
            header_row_index = i
            break

    if header_row_index is None:
        raise ValueError(
            "Could not find 'Code' and 'Definition' headers in the Codebook provided."
        )

    # Adjust the DataFrame to use the identified header row
    df.columns = df.iloc[header_row_index]
    df = df[header_row_index + 1 :].reset_index(drop=True)

    # Create a list to store the JSON objects
    json_list = []

    # Iterate over the DataFrame rows
    for index, row in df.iterrows():

        # Detect analysis question rows
        # 'Code' contains the analysis question, and 'Definition' is NaN
        if pd.notna(row["Code"]) and pd.isna(row["Definition"]):
            current_analysis_question = row["Code"].strip()
            potential_analysis_questions.append(
                current_analysis_question
            )  # Store detected analysis questions

            # If this row matches the analysis question provided by the user, start extracting data
            if current_analysis_question == analysis_question:
                in_target_section = True
                analysis_question_found = True
            else:
                # If already in target section and we hit a new analysis question, stop processing
                if in_target_section:
                    break

        # If we are in the target section, extract the code: definition pairs
        if in_target_section and pd.notna(row["Code"]) and pd.notna(row["Definition"]):
            code = row["Code"].strip()
            definition = row["Definition"].strip()
            if code and definition:
                code_definition = {code: definition}
                json_list.append(code_definition)

    if not analysis_question_found:
        print("Detected analysis questions: ", potential_analysis_questions)
        raise ValueError(f"The analysis question '{analysis_question}' was not found.")

    return json_list, survey_question


def prepare_prompt(json_list, interv_question, response):

    # guidelines = create_guidelines(json_list)
    # Guidelines for Matching Topics: {guidelines}

    prompt = f"""You will be given an interview question, a response transcript, and a JSON object containing the labels and definitions of topics. Your task is to identify the topics mentioned explicitly or implicitly within the response transcript using the JSON object.

    Instructions:

    1. Carefully read the response transcript.
    2. Use the provided JSON object to understand the topics and their definitions.
    3. Identify the topics mentioned explicitly or implicitly within the transcript by finding relevant keywords, phrases, or contextual hints that align with the definitions.
    4. Only include topics listed in the JSON object in your final list.
    5. Return the list of identified topics as comma-separated values.

    Data:

    Interview Question: {interv_question}

    Response Transcript: {response}

    JSON Object: {json_list}

    Example Response: 
    Social knowledge, Declarative knowledge
    
    """
    return prompt


def get_codebook():
    """Prompt user to input the path to the codebook CSV file and return the DataFrame."""
    csv_file = input("Enter path to codebook XLSX: ")
    return xlsx_to_df(csv_file)


def convert_codebook_to_json(df):
    """Convert the codebook DataFrame to JSON format and extract the survey question."""
    json_list, survey_q = csv_to_json(df)
    print(json.dumps(json_list, indent=4))
    return json_list, survey_q


def get_responses_file():
    """Prompt user to input the path to the responses CSV file and return the DataFrame."""
    file_path = input("Enter path to CSV containing responses: ")
    return pd.read_csv(file_path, encoding="utf-8-sig")


def get_response_column_name():
    """Prompt user to input the name of the column containing responses."""
    return input("Enter name of column containing responses: ")


def prepare_gpt_responses(df, response_column, json_list, survey_q):
    """Iterate over the responses DataFrame and generate GPT responses for each row."""
    list_gpt_responses = []

    for index, row in df.iterrows():
        response_transcript = row[response_column]
        prompt = prepare_prompt(json_list, survey_q, response_transcript)
        load_api_key()
        gpt_response = call_gpt(prompt)
        list_gpt_responses.append(gpt_response)

    return list_gpt_responses


def save_responses_to_csv(df, gpt_responses):
    """Save the GPT responses to a new CSV file."""
    df["New Tags Identified (with Codebook)"] = gpt_responses
    user_new_csv = input(
        "Enter the filename for the newly identified tags to be written into (or press Enter to use 'tagsidentified.csv'): "
    )

    # Use 'tagsidentified.csv' if the user presses Enter without input
    new_csv = user_new_csv if user_new_csv else "tagsidentified.csv"

    # Ensure the filename ends with '.csv'
    if not new_csv.endswith(".csv"):
        new_csv += ".csv"

    df.to_csv(new_csv, index=False, encoding="utf-8-sig")


def main():
    # Get and process the codebook
    codebook_df = get_codebook()
    json_list, survey_q = convert_codebook_to_json(codebook_df)

    # Get the responses CSV file and the response column name
    responses_df = get_responses_file()
    response_column = get_response_column_name()

    # Prepare GPT responses based on the responses data
    gpt_responses = prepare_gpt_responses(
        responses_df, response_column, json_list, survey_q
    )

    # Save the GPT responses to a new CSV file
    save_responses_to_csv(responses_df, gpt_responses)


if __name__ == "__main__":
    main()
