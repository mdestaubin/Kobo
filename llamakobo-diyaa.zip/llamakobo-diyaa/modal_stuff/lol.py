# $ python
# >>> import modal
# >>> f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
# >>> f.remote("What is the story about the fox and grapes?")
# 'The story about the fox and grapes ...
# ```

import modal


stub = modal.Stub()

@stub.function()
def foo():
    f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
    print(f.remote("What is your name"))

#if __name__ == '__main__':
 #   f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
 #   f.remote("Give me 3 random words")