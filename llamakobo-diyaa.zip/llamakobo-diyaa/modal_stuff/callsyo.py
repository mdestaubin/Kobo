import subprocess

import modal

def run_modal_command():
    # Define the command to run
    command = ["modal", "run", "test.py"]

    # Run the command
    result = subprocess.run(command, capture_output=True, text=True)
    
    # Check if the command was successful
    if result.returncode == 0:
        print("Command executed successfully!")
#        print("Output:", result.stdout)
    else:
        print("Command failed with error:")
        print(result.stderr)

run_modal_command()