# $ python
# >>> import modal
# >>> f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
# >>> f.remote("What is the story about the fox and grapes?")
# 'The story about the fox and grapes ...
# ```
import subprocess
import modal

stub = modal.Stub()

#@stub.function()
#def foo():
 #   f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
  #  print(f.remote("Summarize the response: Well, I think a lot of people are thinking very negatively about what's going on in the world, but I have to say that overall, you know, I think the long-term trends are looking pretty positive if you just forget about current events, you know. People are healthier and there is less poverty, technology makes things easier for many people in their day-to-day lives.  And of course it doesn't mean there's a lot of suffering. There is.  And there's inequality. But you have to remember that things were actually worse for the vast majority of those people around the planet, you know, 20, 30, 100 years ago, a thousand years ago. So, I think that the current state of the world could be a lot better and I think there's a lot more awareness of what the problems are; the challenges--especially around climate change, for example.") 
#)


@stub.function()
def foo(prompt):
    f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
    response = f.remote("Summarize the response: Well, I think a lot of people are thinking very negatively about what's going on in the world, but I have to say that overall, you know, I think the long-term trends are looking pretty positive if you just forget about current events, you know. People are healthier and there is less poverty, technology makes things easier for many people in their day-to-day lives.  And of course it doesn't mean there's a lot of suffering. There is.  And there's inequality. But you have to remember that things were actually worse for the vast majority of those people around the planet, you know, 20, 30, 100 years ago, a thousand years ago. So, I think that the current state of the world could be a lot better and I think there's a lot more awareness of what the problems are; the challenges--especially around climate change, for example.") 
    print(response)
    return response


#to run the foo function you need to do this in command line:
# modal run test.py --prompt "give me two random words"


#def run_modal_command():

def run_modal_command(prompt):
    command = ["modal", "run", "test.py", "--prompt", prompt]

    # Run the command
    result = subprocess.run(command, capture_output=True, text=True)
    
    # Check if the command was successful
    if result.returncode == 0:
        print("Command executed successfully!")
       # print("Output:", result.stdout)
    else:
        print("Command failed with error:")
        print(result.stderr)
    
    return result.stdout


"""def run_remote(prompt):
    # Define the command to run
    command = ["modal", "run", "test.py", "--prompt", prompt]

    # Run the command
    result = subprocess.run(command, capture_output=True, text=True)
    
    # Check if the command was successful
    if result.returncode == 0:
        print("Command executed successfully!")
       # print("Output:", result.stdout)
    else:
        print("Command failed with error:")
        print(result.stderr)

run_remote("LOL")"""


#rmodal un_remote("lol")
#if __name__ == '__main__':
 #   f = modal.Function.lookup("example-tgi-Llama-2-70b-chat-hf", "Model.generate")
 #   f.remote("Give me 3 random words")

#in order to run foo, you  need to call the stub_function